const express = require('express');
const router = express.Router();
const db = require('../db');

// Create new article
router.post('/', (req, res) => {
  const { title, description, author, status, rating } = req.body;
  const sql = 'INSERT INTO articles (title, description, author, status, rating) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [title, description, author, status, rating], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ message: 'Article created', id: result.insertId });
  });
});

// Get article by ID
router.get('/:id', (req, res) => {
  db.query('SELECT * FROM articles WHERE id = ?', [req.params.id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ message: 'Article not found' });
    res.json(results[0]);
  });
});

// Get all articles
router.get('/', (req, res) => {
  db.query('SELECT * FROM articles', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Update article rating/status
router.put('/:id', (req, res) => {
  const { status, rating } = req.body;
  const sql = 'UPDATE articles SET status = ?, rating = ? WHERE id = ?';
  db.query(sql, [status, rating, req.params.id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Article not found' });
    res.json({ message: 'Article updated' });
  });
});

// Delete article
router.delete('/:id', (req, res) => {
  db.query('DELETE FROM articles WHERE id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Article not found' });
    res.json({ message: 'Article deleted' });
  });
});

module.exports = router;