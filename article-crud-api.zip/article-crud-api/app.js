const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',  // your MySQL root password here
  database: 'article_db'
});

db.connect(err => {
  if (err) {
    console.error('Database connection failed:', err);
  } else {
    console.log('Connected to MySQL database...');
  }
});

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the Article CRUD API');
});

// CREATE - Add a new article
app.post('/articles', (req, res) => {
  const { title, description, author, status, rating } = req.body;
  if (!title || !description || !author || !status || rating == null) {
    return res.status(400).json({ message: 'Please provide title, description, author, status, and rating' });
  }

  const sql = `INSERT INTO articles (title, description, author, status, rating) VALUES (?, ?, ?, ?, ?)`;
  db.query(sql, [title, description, author, status, rating], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Database error' });
    }
    // Return the created article with ID
    res.status(201).json({ id: result.insertId, title, description, author, status, rating });
  });
});

// READ - Get all articles
app.get('/articles', (req, res) => {
  const sql = `SELECT * FROM articles`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Database error' });
    }
    res.json(results);
  });
});

// READ - Get article by ID
app.get('/articles/:id', (req, res) => {
  const { id } = req.params;
  const sql = `SELECT * FROM articles WHERE id = ?`;
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Database error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json(results[0]);
  });
});

// UPDATE - Update rating/status of an article
app.put('/articles/:id', (req, res) => {
  const { id } = req.params;
  const { rating, status } = req.body;

  if (rating == null && !status) {
    return res.status(400).json({ message: 'Please provide rating and/or status to update' });
  }

  let fields = [];
  let values = [];

  if (rating != null) {
    fields.push('rating = ?');
    values.push(rating);
  }
  if (status) {
    fields.push('status = ?');
    values.push(status);
  }
  values.push(id);

  const sql = `UPDATE articles SET ${fields.join(', ')} WHERE id = ?`;
  db.query(sql, values, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Database error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json({ message: 'Article updated successfully' });
  });
});

// DELETE - Delete an article by ID
app.delete('/articles/:id', (req, res) => {
  const { id } = req.params;
  const sql = `DELETE FROM articles WHERE id = ?`;
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Database error' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json({ message: 'Article deleted successfully' });
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
